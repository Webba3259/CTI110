Fnumber = int(input())
Snumber = int(input())
Sum = Fnumber + Snumber
Product = Fnumber * Snumber
print('1st number:', Fnumber)
print('2nd number:', Snumber)
print('sum is:', Sum)
print('product is:', Product)